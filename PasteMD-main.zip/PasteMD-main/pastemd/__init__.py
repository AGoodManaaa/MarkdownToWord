"""PasteMD - Markdown to DOCX conversion with hotkey support."""

__version__ = "0.1.6.0"
__app_name__ = "PasteMD"
