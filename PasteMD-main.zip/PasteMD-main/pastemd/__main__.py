"""Application main entry point."""

if __name__ == "__main__":
    from .app.app import main
    main()
