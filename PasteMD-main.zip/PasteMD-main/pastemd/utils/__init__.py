"""Utility functions and platform tools."""
