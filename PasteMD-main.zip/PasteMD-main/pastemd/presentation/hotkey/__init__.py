"""Hotkey UI components."""

from .dialog import HotkeyDialog

__all__ = ["HotkeyDialog"]
