"""Document insertion domain."""
