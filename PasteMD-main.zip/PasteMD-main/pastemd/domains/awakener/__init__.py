"""Awakener domain - handles application awakening (launching)."""

from .launcher import AppLauncher

__all__ = ["AppLauncher"]
