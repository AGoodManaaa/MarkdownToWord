"""Business domain capabilities."""
