"""Hotkey management domain."""
