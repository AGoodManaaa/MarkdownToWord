"""Notification domain."""
