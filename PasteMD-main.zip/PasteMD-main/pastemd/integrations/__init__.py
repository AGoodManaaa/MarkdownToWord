"""External tool integrations."""
