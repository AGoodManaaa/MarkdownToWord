"""Legacy main entry point for backwards compatibility."""

if __name__ == "__main__":
    from pastemd.app.app import main
    main()